var Edge = Class
		.extend({
			init : function(from, to) {
				this.from = 0;
				this.to = 0;
				this.type = 1;
				this.len = 0;
				this.fromNode = from;
				this.toNode = to;
				this.lastLen = 0;
				this.currentLen = 0;
				this.HtmlID = Function.genId('Edge-id', 10, 6);
				
				this.NoPaint = false;

				this.isIE = navigator.userAgent.indexOf("MSIE") > -1;

				this.line = document.createElement("div");
				this.line.className = "TCD-Edge-line";
				this.line.id = this.HtmlID;
				if (this.isIE) {
					this.paint = function() {
						if (this.NoPaint)
							return;
						var x1 = this.fromNode.oldX;
						var y1 = this.fromNode.oldY;
						var x2 = this.toNode.oldX;
						var y2 = this.toNode.oldY;
						
						if (this.fromNode.moved || this.toNode.moved)
							this.paintIE(x1, y1, x2, y2);
					};
				} else {
					this.paint = function() {
						if (this.NoPaint)
							return;
						var x1 = this.fromNode.oldX;
						var y1 = this.fromNode.oldY;
						var x2 = this.toNode.oldX;
						var y2 = this.toNode.oldY;
						
						if (this.fromNode.moved || this.toNode.moved)
							this.paintOther(x1, y1, x2, y2);
					};
				}
				this.paint();
			},
			
			getElement : function()
			{
				return this.line;
			},

			paintOther : function(x1, y1, x2, y2) {
				if (x2 < x1) {
					var temp = x1;
					x1 = x2;
					x2 = temp;
					temp = y1;
					y1 = y2;
					y2 = temp;
				}
				
				this.lastLen = this.len;
				var length = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
				this.currentLen = length;

				this.line.style.width = length + "px";

				var angle = Math.atan((y2 - y1) / (x2 - x1));
				this.line.style.top = y1 + 0.5 * length * Math.sin(angle)
						+ "px";
				this.line.style.left = x1 - 0.5 * length
						* (1 - Math.cos(angle)) + "px";
				this.line.style.MozTransform = this.line.style.WebkitTransform = this.line.style.OTransform = "rotate("
						+ angle + "rad)";
			},
			
			paintIE : function(x1, y1, x2, y2) {
				if (x2 < x1) {
					var temp = x1;
					x1 = x2;
					x2 = temp;
					temp = y1;
					y1 = y2;
					y2 = temp;
				}
				
				this.lastLen = this.len;
				var length = Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
				this.currentLen = length;

				this.line.style.width = length + "px";

				this.line.style.top = (y2 > y1) ? y1 + "px" : y2 + "px";
				this.line.style.left = x1 + "px";
				var nCos = (x2 - x1) / length;
				var nSin = (y2 - y1) / length;
				this.line.style.filter = "progid:DXImageTransform.Microsoft.Matrix(sizingMethod='auto expand', M11="
						+ nCos
						+ ", M12="
						+ -1
						* nSin
						+ ", M21="
						+ nSin
						+ ", M22=" + nCos + ")";
			}
            , checkConflict : function(edge)
            {
                if (!this.fromNode || !this.toNode)
                    return false;

                if (this.fromNode.HtmlID == edge.fromNode.HtmlID)
                    return false;
                if (this.fromNode.HtmlID == edge.toNode.HtmlID)
                    return false;

                if (this.toNode.HtmlID == edge.fromNode.HtmlID)
                    return false;
                if (this.toNode.HtmlID == edge.toNode.HtmlID)
                    return false;

                if (this.toNode.nodeType == 'ExtendPoint')
                    return false;
                if (this.fromNode.nodeType == 'ExtendPoint')
                    return false;

                if (edge.toNode.nodeType == 'ExtendPoint')
                    return false;
                if (edge.fromNode.nodeType == 'ExtendPoint')
                    return false;

                /*
                if (this.toNode.numOfChild > 0)
                    return this.len;
                /**/

                var a1 = (this.fromNode.y-this.toNode.y)/(this.fromNode.x-this.toNode.x);
                var b1 = this.fromNode.y - a1*this.fromNode.x;

                var a2 = (edge.fromNode.y-edge.toNode.y)/(edge.fromNode.x-edge.toNode.x);
                var b2 = edge.fromNode.y - a2*edge.fromNode.x;

                // find intersection point
                // y = a1x + b1
                // y = a2x + b2
                // a1x + b1 = a2x + b2
                // (a1 - a2)x = b2 - b1
                var x = (b2 - b1)/(a1 - a2);
                var y = a1*x+b1;

                var addExtra = 5;

                if (
                    x <= Math.max(this.fromNode.x, this.toNode.x) + addExtra && x >= Math.min(this.fromNode.x, this.toNode.x) - addExtra
                        && y <= Math.max(this.fromNode.y, this.toNode.y) + addExtra && y >= Math.min(this.fromNode.y, this.toNode.y) - addExtra
                        && x <= Math.max(edge.fromNode.x, edge.toNode.x) + addExtra && x >= Math.min(edge.fromNode.x, edge.toNode.x) - addExtra
                        && y <= Math.max(edge.fromNode.y, edge.toNode.y) + addExtra && y >= Math.min(edge.fromNode.y, edge.toNode.y) - addExtra
                    )
                {
                    return true;
                    /*
                    var vx = this.fromNode.x - x;
                    var vy = this.fromNode.y - y;
                    var len = Math.sqrt(vx * vx + vy * vy);
                    len = (len == 0) ? this.len : len;

                    return len;
                    /**/
                }
                else
                    return false;

            }
		});