var ExtendPoint = Node.extend({
	init : function(parent) {
		this._super(parent, -3, false);
		this.lbl = "ExtendPoint";
		this.width = this.height = 9;
		this._parent = null;
		this._len = 0;
		this._to = null;// Node;
		
		this.nodeType = "ExtendPoint";
	}

	,
	//GraphPanel parent,Node to, int len
	startWait : function(parent, to, len) {
		this._parent=parent;
		this._len=len;
		this._to=to;
		var _this = this;
		setTimeout(function() { _this.run(); }, Math.floor(Math.random() * 70));
	}
	
	, stop : function()
	{
		this._parent=null;
		this._to=null;
	}
	
	, run : function()
	{
		var dx=(this.x-this.ParentNode.x)/4;
		var dy=(this.y-this.ParentNode.y)/4;
		this._to.x=this.x+dx;
		this._to.y=this.y+dy;
		this._parent.addEdge(this, this._to, this._len, false);
		this.stop();
	}
	
	,getToolTip : function()
	{
		return null;
	}
	
});






