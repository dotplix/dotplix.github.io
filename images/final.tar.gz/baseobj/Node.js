/**
 * Base node type. All node in the graph mush be extend from this class.
 * @type {*}
 */
var Node = Class.extend({

	init : function(parent, ID, isFixed) {
		if (typeof isFixed == 'undefined')
			isFixed = false;
		// this.Parent;
		// this.imageInfo=new ImageInfo();

		this.Key = 0;
		this.fixed = false;

		this.x = -1;
		this.y = -1;

		this.dx = 0;
		this.dy = 0;
		
		this.minMoveLeng = 30;//If move to new position which len^2 < this value, the move funciton will do nothing

		this.Level = 0;

		this.lbl = "";

		this.width = 0;
		this.height = 0;

		this.check = false;

		this.numOfChild = 0;

		this.ParentNode = null;

		this.lbl = "";
		this.Key = ID;
		this.fixed = isFixed;
		this.Parent = parent;
		this.toolTip = "";
		this.htmlCode = "";
		this.imageInfo = new ImageInfo();

		this.nodeType = "Node";

		this.moveRandom();

		this.HtmlID = Function.genId('Node-id', 10, 5);

		this.node = document.createElement("div");
		this.node.className = "TCD-Node-data";
		this.node.id = this.HtmlID;
		this.node.innerHTML = this.htmlCode;
		//this.node.style.width = this.width;
		//this.paint();
		this.moved = true;
		this.draging = false;
	}

	,
	setHtmlCode : function(code) {
		this.node.innerHTML = this.htmlCode = code;
		this.height = 0;// document.getElementById(this.HtmlID).offsetHeight;
	}

	,
	setHtmlCodeFromElement : function(elementId) {
        var elem = document.getElementById(elementId);
        var html = elem.outerHTML;
        elem.parentNode.removeChild(elem);
		this.node.innerHTML = this.htmlCode = html;
		this.height = 0;// document.getElementById(this.HtmlID).offsetHeight;
        this.node.id = this.HtmlID = 'Node-' + elementId;
	}
    
	,
	addHtmlNode : function(elementId, edgelen) {
        var nn = new ItemNode(this.Parent);
        //Set the innerHTML for the new node
        nn.setHtmlCodeFromElement(elementId);
        //Add node into the panel
        this.Parent.addNode(nn);
        //Add relationship between parrent and new node
        this.Parent.addEdge(this, nn, edgelen);
        
        return nn;
	}
    
    ,
    getHtmlAttribute : function(name){
        try{
            return this.node.childNodes[0].getAttribute(name);
        }
        catch(e){
            return false;
        }
    }
    
	,
	getName : function() {
		return this.nodeType;
	}

	,
	moveRandom : function() {
		if (this.draging)
			return;
		this.x = Math.floor(Math.random() * this.Parent.width / 4) + this.Parent.width / 4;
		this.y = Math.floor(Math.random() * this.Parent.height / 4) + this.Parent.height / 4;
		//this.x = this.Parent.width / 2 + Math.floor(Math.random() * 10) - 5;
		//this.y = this.Parent.height / 2 + Math.floor(Math.random() * 10) - 5;
		this.oldX = this.x;
		this.oldY = this.y;
		this.moved = true;
	}

	,
	InNode : function(tx, ty) {
		var x = this.x;
		var y = this.y;
		var l = x - width / 2;
		var t = y - height / 2;
		var r = l + width;
		var b = t + height;
		if (tx < l)
			return false;
		if (tx > r)
			return false;
		if (ty < t)
			return false;
		if (ty > b)
			return false;
		return true;
	}

	,
	
	getElement : function()
	{
		return this.node;
	},

	getToolTip : function() {
		return this.toolTip;
	}

	,
	getHtmlCode : function() {
		return this.htmlCode;
	}
	
	,
	paint : function() {
		if (!this.moved)
			return;
		this.moved = false;
		if (this.height == 0) {
			this.height = document.getElementById(this.HtmlID).offsetHeight;
		}
		if (this.width == 0) {
			this.width = document.getElementById(this.HtmlID).offsetWidth;
		}

		this.node.style.top = (this.y - this.height / 2) + "px";
		this.node.style.left = (this.x - this.width / 2) + "px";

	}

	,
	move : function() {
		if (this.draging)
			return;
		
        var dx;
        var dy;
        if (this.numOfChild > 1)
        {
            dx = Math.max(-5, Math.min(5, this.dx));// / Math.max((this.numOfChild/3),5);
            dy = Math.max(-5, Math.min(5, this.dy));// / Math.max((this.numOfChild/3),5);
        }
        else
        {
            var dx = Math.max(-10, Math.min(10, this.dx));
            var dy = Math.max(-10, Math.min(10, this.dy));
        }

		var x1 = this.oldX;
		var y1 = this.oldY;
		var x2 = this.x + dx;
		var y2 = this.y + dy;
		this.Movelength = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2);
		if (this.Movelength > this.minMoveLeng)
		{
			this.oldX = this.x;
			this.oldY = this.y;
			this.moved = true;
		}
		this.x = x2;
		this.y = y2;
		this.fixOut();
	}

	,
	stop : function() {
	},
	start : function() {
	}
	
	, fixOut : function()
	{
		if (this.x < this.width)
		{
			this.moved = true;
			this.x = this.width;
		}
		if (this.y < this.height)
		{
			this.moved = true;
			this.y = this.height;
		}
		if (this.x + this.width > this.Parent.width)
		{
			this.moved = true;
			this.x = this.Parent.width - this.width;
		}
		if (this.y + this.height > this.Parent.height)
		{
			this.moved = true;
			this.y = this.Parent.height - this.height;		
		}
	}
	
	,
	
	hadDrag : false,
	
	initHandler : function()
	{
		var obj = document.getElementById(this.HtmlID);
		
		var dragable = DragHandler.attach(obj);
		
		var _this = this;
		
		dragable.dragBegin = function (element, x, y)
		{
			_this.draging = true;
		};
		
		dragable.drag = function (element, x, y){
			_this.x = x + element.offsetWidth / 2;
			_this.y = y + element.offsetHeight / 2;
			_this.fixOut();
			_this.fixedPosX = _this.oldX = _this.x;
			_this.fixedPosY = _this.oldY = _this.y;
			_this.moved = true;
			_this.paint();
			_this.moved = true;
			_this.Parent.paintEdge();
			_this.Parent.restart();
			_this.hadDrag = true;
		};
		
		dragable.dragEnd = function (element, x, y)
		{
			_this.draging = false;
			_this.dx = 0;
			_this.dy = 0;
		};
		
		obj.onclick = function (){
			if (_this.hadDrag)
			{
				_this.hadDrag = false;
				return;
			}
			_this.Parent.mouseClick(_this);
		};
		
		obj.onmouseover = function (){
			_this.Parent.mouseOver(_this);
		};
		
		
		
	}
});
