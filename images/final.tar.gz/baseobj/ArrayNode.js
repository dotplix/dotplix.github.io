var ArrayNode = ArrayList.extend({
	find : function(Key)// Node
	{
		for ( var i = 0; i < this.size(); i++) {
			if (this.get(i).Key == Key) {
				return this.get(i);
			}
		}
		return null;
	}

	,
	find : function(/* node */ n)// Node
	{
		return this.indexOf(n);
	}
	
	,
	
	findByHtmlID : function(HtmlID)// Node
	{
		for ( var i = 0; i < this.size(); i++) {
			if (this.get(i).HtmlID == HtmlID) {
				return this.get(i);
			}
		}
		return null;
	}	
	
});