var ArrayEdge = ArrayList.extend({
	check : function(node1, node2)//int int
	{
		for (var i = 0; i<this.size(); i++) 
		{
			if (this.get(i).from==node1 && this.get(i).to==node2)
				return true;
	    }
	    return false;
	}
	
	, checkAll : function(node1, node2)
	{
		for (var i = 0; i<this.size(); i++) 
		{
			if (this.get(i).from==node1 && this.get(i).to==node2)
				return true;
			if (this.get(i).from==node2 && this.get(i).to==node1)
				return true;
	    }
	    return false;
	}

});