var GraphPanel = Class.extend({

	init : function(parent) {
		this.nnodes = 0;
		this.nodes = new ArrayNode();
		this.edges = new ArrayEdge();
		this.centerNode = null;
		this.relaxer = null;
		this.numMouseButtonsDown = 0;
		this.xong = false;
		this.old = -1;
		this.pick = null;
		this.pickfixed = false;
		this.parent = parent;
		this.parentElement = document.getElementById(this.parent);
		if (this.parentElement != null)
		{
			this.width = this.parentElement.offsetWidth;
			this.height = this.parentElement.offsetHeight;
		}
		else
			{
			this.width = 100;
			this.height = 100;
			}
		this.size = new Dimension();
		this.size.width = this.width;
		this.size.height = this.height;

		this.countNoMove = 0;
        this.countNoConflict = 0;
		
		this.start();
		
		this.initHandler();
	},
	
	initHandler : function()
	{
		this.mouseClick = function(node){};
		this.mouseOver = function(node){};
	}

	,
	restart : function()
	{
		this.xong = false;
		if (this.relaxer == null)
			this.start();
	}
	,
	start : function() {
		this.stop();
		var _this = this;
		this.relaxer = setInterval(function() { _this.run(); }, 5);
	}

	,
	stop : function() {
		this.relaxer = clearInterval(this.relaxer);
		this.countNoMove = 0;
        this.countNoConflict = 0;
		this.relaxer = null;
	}

	,
	findNode : function(/* Node */n) {
		for ( var i = 0; i < this.nnodes; i++) {
			if (this.nodes.get(i).equals(n)) {
				return i;
			}
		}
		return this.addNode(n);
	}

	,

	findNode2 : function(/* Node */n) {
		for ( var i = 0; i < this.nnodes; i++) {
			if (this.nodes.get(i).equals(n)) {
				return i;
			}
		}
		return -1;
	}

	,

	findNode : function(/* long */Key) {
		for ( var i = 0; i < this.nnodes; i++) {
			if (this.nodes.get(i).Key == Key) {
				return this.nodes.get(i);
			}
		}
		return null;
	}
	
	,

	findNodebyHtmlId : function(id)
	{
		return this.nodes.findByHtmlID(id);
	}

	,

	clearNode : function() {
		for ( var i = 0; i < this.nodes.size(); i++) {
			var n = this.nodes.get(i);
			n.stop();
			n.ParentNode = null;
		}
		this.centerNode = null;
		this.pick = null;
		this.nnodes = 0;
		this.edges.clear();
		this.nodes.clear();
		this.xong = false;
	}

	,

	/* public int */addNode : function(/* Node */n) {
		n.start();
		if (n.x <= 0 || n.y <= 0) {
			n.moveRandom();
		}

		this.nodes.add(n);
		
		this.parentElement.appendChild(n.getElement());
		n.paint();

		this.nnodes++;
		this.xong = false;
		
		if (n.getName() == 'CenterNode')
			this.centerNode = n;
		
		this.restart();
		n.initHandler();
		return this.nnodes;
	}
	
	, addEdgeFore: function(/* Node */from, /* Node */to, /* int */	len) 
	{
		var e = new Edge(from, to);
		to.ParentNode = from;
		e.to = this.findNode(to);
		e.from = this.findNode(from);
		e.len = len + len * (from.numOfChild - 1) / 15;
		e.NoPaint=true;
		this.edges.add(e);
		this.xong = false;
		this.restart();
		this.parentElement.appendChild(e.getElement());
	}

	,

	/* public void */addEdge : function(/* Node */from, /* Node */to, /* int */	len) {
		var e = new Edge(from, to);
		
		if (this.centerNode != null && from.getName() != "CenterNode")
		{
			to.x = from.x;
			to.y = from.y;
			to.dx = this.centerNode.x - from.x;
			to.dy = this.centerNode.y - from.y;
		}
		
		from.numOfChild++;
		if (from.numOfChild >= 20) {
			var ep = new ExtendPoint(from.Parent);
			ep.x = to.x + len / 2 - Math.floor(Math.random() * len);
			ep.y = to.y + len / 2 - Math.floor(Math.random() * len);

			e.from = this.findNode(from);
			e.to = this.addNode(ep);
			e.len = len * 1.1 + len * (from.numOfChild - 20) / 10;
			e.type = 0;
			e.toNode = ep;
			this.edges.add(e);

			ep.ParentNode = from;

			ep.startWait(this, to, len / 4 * 3);
		} else if (from.numOfChild >= 10) {
			var ep = new ExtendPoint(from.Parent);
			ep.x = to.x + Math.floor(Math.random() * len - len / 2);
			ep.y = to.y + Math.floor(Math.random() * len - len / 2);

			e.from = this.findNode(from);
			e.to = this.addNode(ep);
			e.toNode = ep;
			e.len = len + len * (from.numOfChild - 9) / 10;
			e.type = 0;
			this.edges.add(e);

			ep.ParentNode = from;

			ep.startWait(this, to, len / 4 * 3);
		} else {
			to.ParentNode = from;
			e.to = this.findNode(to);
			e.from = this.findNode(from);
			e.len = len + len * (from.numOfChild - 1) / 15;
			this.edges.add(e);
		}
		this.xong = false;
		this.restart();
		this.parentElement.appendChild(e.getElement());
	}
	,
	run : function() {
		if (this.xong)
			return;
		this.relax();
	}

	,
	getSize : function()// Get container size
	{
		return this.size;
	}

	,
	relax : function() {
		
		if (this.edges.size() == 0 && this.nnodes == 0)
			{
				this.xong = true;
				return;
			}


        var avg_x = 0;
        var avg_y = 0;
        var count_has_child = 0;

        // Chinh lai toa do cua node
        for ( var i = 0; i < this.nnodes; i++) {
            var n1 = this.nodes.get(i);
            var dx = 0;
            var dy = 0;

            if (n1.fixed || n1.draging)
                continue;

            if (n1.numOfChild > 0)
            {
                avg_x += n1.x;
                avg_y += n1.y;
                count_has_child ++;
            }

            for ( var j = 0; j < this.nnodes; j++) {
                if (i == j) {
                    continue;
                }
                var n2 = this.nodes.get(j);
                if (n2.getName() == "ExtendPoint") {
                    continue;
                }
                var vx = n1.x - n2.x;
                var vy = n1.y - n2.y;
                var len = vx * vx + vy * vy;
                if (len == 0) {
                    dx += Math.random();
                    dy += Math.random();
                } else //if (len < 50000)
                {
                    if (n1.Level < n2.Level) {
                        dx += vx / len / 5;
                        dy += vy / len / 5;
                    } else {
                        dx += vx / len;
                        dy += vy / len;
                    }
                }
            }
            var dlen = dx * dx + dy * dy;
            if (dlen > 0) {
                dlen = Math.sqrt(dlen) / 3.6;
                dx /= dlen;
                dy /= dlen;
                n1.dx += dx;
                n1.dy += dy;
            }
            //n.move();
        }

		// Chinh lai do dai cac canh
		for ( var i = 0; i < this.edges.size(); i++) {
			var e = this.edges.get(i);
            var edge_len = e.len;
            /*
            for ( var j = 0; j < this.edges.size(); j++) {
                if (i == j)
                    continue;
                var t = e.checkConflict(this.edges.get(j));
                if (t < edge_len)
                    edge_len = t;
            }
            */

			var vx = e.toNode.x - e.fromNode.x;
			var vy = e.toNode.y - e.fromNode.y;
			var len = Math.sqrt(vx * vx + vy * vy);
			len = (len == 0) ? .0001 : len;
			var f = (edge_len - len) / (len * 3);
			var dx = f * vx;
			var dy = f * vy;

			e.fromNode.dx += -dx;
			e.fromNode.dy += -dy;

			e.toNode.dx += dx;
			e.toNode.dy += dy;
		}

        //Move the centered node to the center
        if (count_has_child > 0)
        {
            avg_x /= count_has_child;
            avg_y /= count_has_child;
        }


        var center_vx = avg_x - this.width / 2;
        var center_vy = avg_y - this.height / 2;
        var center_len = Math.sqrt(vx * vx + vy * vy);
        center_len = (center_len == 0) ? .0001 : center_len;
        var center_dx = center_vx / 5;
        var center_dy = center_vy / 5;

        //Find the nearest node to center of map
        for ( var i = 0; i < this.nnodes; i++) {
            var n1 = this.nodes.get(i);

            if (n1.numOfChild == 0)
                continue;

            n1.dx -= center_dx;
            n1.dy -= center_dy;
        }



		for ( var i = 0; i < this.nnodes; i++) {
			var n = this.nodes.get(i);
			n.move();
			n.dx /= 2;
			n.dy /= 2;
		}
		
		//Ve cac canh truoc
		this.paintEdge();
				
		var moved = 0;
		
		for ( var i = 0; i < this.nnodes; i++) {
			var n = this.nodes.get(i);
			if (n.draging || n.moved && n.getName() != "ExtendPoint")
				moved++;
			n.paint();
		}

        var isConflict = false;
        for ( var i = 0; i < this.edges.size(); i++) {
            var e = this.edges.get(i);
            for ( var j = 0; j < this.edges.size(); j++) {
                if (i == j)
                    continue;
                if (e.checkConflict(this.edges.get(j)))
                {
                    isConflict = true;
                    break;
                }
            }
            if (isConflict)
                break;
        }

        if (!isConflict)
            this.countNoConflict++;
        else
        {
            this.countNoMove = 0;
            this.countNoConflict = 0;
        }


        if (moved == 0)
            this.countNoMove ++;

        //var c = this.nodes.get(0);

        //c.setHtmlCode((isConflict?'CF':'NC') + ';CM: ' + this.countNoMove + ';CC: ' + this.countNoConflict);

        if (!isConflict && (this.countNoConflict >= 210 || this.countNoMove >= 3 && this.countNoConflict >= 10))
        {
            this.stop();
            this.xong = true;
            //this.start();
        }

	}
	,
	paintNode : function(n) {
		n.paint();
	}
	
	, paintId : 0
	
	, paintEdge : function ()
	{
		this.paintId ++;
		var my = this.paintId;
		for ( var i = 0; i < this.edges.size(); i++) {
			if (my != this.paintId)
				return;
			var e = this.edges.get(i);
			e.paint();
		}
	}

	,
	paint : function() {
		for ( var i = 0; i < this.edges.size(); i++) {
			var e = this.edges.get(i);
			e.paint();
		}
		for ( var i = 0; i < this.nnodes; i++) {
			var n = this.nodes.get(i);
			n.paint();
		}
	}

});