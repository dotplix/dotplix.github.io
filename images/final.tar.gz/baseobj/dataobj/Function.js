/**
 * Base function which is used by many object
 * @type {*}
 */
var cFunction = Class.extend({
	init : function() {
	},
	
	genId : function(prefix, len, block)
	{
		var id = "" + prefix;
		len = Math.pow(10, len);
		for (var i = 0; i < block ; i++)
		{
			id += "-" + Math.floor(Math.random() * len);
		}
		return id;
	}

	
});

Function = new cFunction();