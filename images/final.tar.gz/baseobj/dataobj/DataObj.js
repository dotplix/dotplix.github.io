/**
 * A category
 * @type {*}
 */
var Category = Class.extend({
	init : function() {
		this.ID = 0;
		this.name = "";
	}
});

/**
 * Store the node information
 * @type {*}
 */
var ImageInfo = Class.extend({
	init : function() {
		this.ID = 0;
		this.path = "";
		this.category = new Category();
		this.author = "";
	}
});

/**
 * Dimension structor
 * @type {*}
 */
var Dimension = Class.extend({
	width : 0,
	height : 0
});

var ArrayList = Class.extend({
	init : function() {
		this.data = new Array();
	}

	,
	get : function(index) {
		if (this.data.length > index)
			return this.data[index];

		return null;
	}

	,
	size : function() {
		return this.data.length;
	}
	
	,
	add : function(obj)
	{
		this.data.push(obj);
	}

	,
	indexOf : function(elt /* , from */) {
		var len = this.length;

		var from = Number(arguments[1]) || 0;
		from = (from < 0) ? Math.ceil(from) : Math.floor(from);
		if (from < 0)
			from += len;

		for (; from < len; from++) {
			if (from in this && elt.equals(this[from]))
				return from;
		}
		return -1;
	}
	,
	clear : function()
	{
		this.data = new Array();
	}
});