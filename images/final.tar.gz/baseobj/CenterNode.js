var CenterNode = Node.extend({
	init : function(parent) {
		this._super(parent, -1, true);
		this.MAX_WIDTH=100;
		this.MAX_HEIGHT=70;
		this.fixedPosX=-1;
		this.fixedPosY=-1;
		this.step=5;
		this.zoom=false;
		this.fixedPosX=this.x;
		this.fixedPosY=this.y;
		
		this.theard = null;
		
		this.nodeType = "CenterNode";
		
		var parentElement = this.Parent.parentElement;
		
		if (parentElement != null)
		{
			this.x = this.fixedPosX = parentElement.offsetWidth / 2;
			this.y = this.fixedPosY = parentElement.offsetHeight / 2;
		}
		
	}

	,
	move : function() {
		return;//Can't move
	}
	
	, start : function()
	{
		var _this = this;
		this.theard = setInterval(function() { _this.run(); }, 10);
	}
	
	, stop : function()
	{
		this.theard = clearInterval(this.theard);
	}
	
	, run : function()
	{
		if (this.draging)
			return;
		this.Parent.xong = false;
		if (this.fixedPosX<0)
		{
			this.fixedPosX=this.x;
		}
		if (this.fixedPosY<0)
		{
			this.fixedPosY=this.y;
		}
		if (this.x!=this.fixedPosX || this.y!=this.fixedPosY)
		{
			var dx=Math.abs(this.x-this.fixedPosX);
			var dy=Math.abs(this.y-this.fixedPosY);
			var sx=this.step;
			var sy=dy*sx/dx;
			if (dx<sx || dy<sy)
			{
				this.x=this.fixedPosX;
				this.y=this.fixedPosY;
			}
			if (this.fixedPosX>=0 && this.x!=this.fixedPosX)
			{
				if (this.x<this.fixedPosX)
					this.x+=sx;
				else
					this.x-=sx;
			}
			if (this.fixedPosY>=0 && this.y!=this.fixedPosY)
			{
				if (this.y<this.fixedPosY)
					this.y+=sy;
				else
					this.y-=sy;
			}
		}
		else
		{
			this.step=5;
		}
		this.oldX = this.x;
		this.oldY = this.y;
		this.moved = true;
		this.paint();
		this.Parent.paintEdge();
	}
});