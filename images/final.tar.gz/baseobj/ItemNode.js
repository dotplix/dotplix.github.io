var ItemNode = Node.extend({
	init : function(parent, ID) {
		if (typeof ID == 'undefined')
			ID = -1;
		this._super(parent, ID, false);
		this.nodeType = 0;
		this.imageInfo.ID=ID;
		this.arcAngle = 0;
		
		this.nodeType = "ItemNode";
	}
	
	
});